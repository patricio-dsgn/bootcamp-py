""" La clase Proveedor tendrá los siguientes atributos:
● ID
● Nombre
● Tipo de productos que ofrece
Métodos:
● Inscripción en bodega  ??????????????????
● Modificar el tipo de producto ofrecido. """


class Proveedor:
    def __init__(self, ID, name, product_type):
        self.ID=ID
        self.name=name
        self.product_type=product_type
    

    def warehouse_reg():
        pass

    def change_type():
        pass
    